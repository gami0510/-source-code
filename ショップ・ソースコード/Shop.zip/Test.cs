
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
 
public class Test : MonoBehaviour {

    public static int money = 1000;

    // Use this for initialization
    void Start () {

        Text t = GameObject.Find("Canvas").transform.Find("Text").GetComponent<Text>();
        t.text =  money.ToString()+"G";
         
    }
}
