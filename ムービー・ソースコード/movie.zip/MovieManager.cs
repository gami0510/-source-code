using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Video;
using UnityEngine.SceneManagement;

public class MovieManager : MonoBehaviour
{
    // ビデオプレイヤー
    public VideoPlayer moviePlayer;
    
    // 再生する動画
    public VideoClip[] movies;
    
    public static string nextScene = "Titlemain";
    public static int movieID = -1;
    // Start is called before the first frame update
    void Start()
    {
        FindObjectOfType<SoundManager>().StopBgm();
        if(movieID >= 0 && movieID < movies.Length)
        {
            moviePlayer.clip = movies[movieID];
            moviePlayer.loopPointReached += MovieEnd;
            moviePlayer.Play();
        }
        else
        {
            SceneManager.LoadScene("Titlemain");
        }
    }
    
    public void MovieEnd(VideoPlayer vp)
    {
        SceneManager.LoadScene(nextScene);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
