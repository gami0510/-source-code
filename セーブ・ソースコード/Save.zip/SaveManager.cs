using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public static class SaveManager
{
    private static SaveData savedata = new SaveData();

    public static void SetStarting()
    {
        savedata.ResetData();
    }
    
    public static bool SaveFileExists()
    {
        string directory = Application.persistentDataPath + @"/Save";
        string path = directory + "/savefile.sav";
        
        return Directory.Exists(directory) && File.Exists(path);
    }
    
    public static void DeleteSaveData()
    {
        if(SaveFileExists())
        {
            string path = Application.persistentDataPath + @"/Save/savefile.sav";
            File.Delete(path);
        }
    }
    
    public static bool Save()
    {
        string directory = Application.persistentDataPath + @"/Save";
        string path = directory + "/savefile.sav";
        
        if(!Directory.Exists(directory))
        {
            Directory.CreateDirectory(directory);
        }


        byte[] data = savedata.ConvertToByte();
        File.WriteAllBytes(path, data);

        return true;
    }
    
    public static void Load()
    {
        string directory = Application.persistentDataPath + @"/Save";
        string path = directory + "/savefile.sav";

        if(Directory.Exists(directory) && File.Exists(path))
        {
            byte[] data = File.ReadAllBytes(path);
            savedata.ConvertFromByte(data);
        }
        else
        {
            savedata.ResetData();
        }
    }
    
    public static bool DeckSave(int deckNum, int[] deck)
    {
        savedata.SetDeck(deckNum, deck);
        return Save();
    }
    
    public static int[] DeckLoad(int deckNum)
    {
        Load();
        int[] deck;
        savedata.GetDeck(out deck, deckNum);
        return deck;
    }
    
    public static int[] DeckLoad()
    {
        Load();
        int[] deck;
        savedata.GetDeck(out deck);
        return deck;
    }
    
    public static bool MoneySave(int money)
    {
        savedata.SetMoney(money);
        return Save();
    }
    
    public static int MoneyLoad()
    {
        Load();
        int money = savedata.GetMoney();
        return money;
    }
    
    public static bool CardNumSave(int id, int num)
    {
        savedata.SetCardNum(id, num);
        return Save();
    }
    public static int CardNumLoad(int id)
    {
        Load();
        return savedata.GetCardNum(id);
    }
    public static bool CardFlagLoad(int id)
    {
        Load();
        return savedata.GetCardFlag(id);
    }
    
    public static bool UseItemsSave(int[] useItems)
    {
        savedata.SetUseItems(useItems);
        return Save();
    }
    public static int[] UseItemsLoad()
    {
        Load();
        int[] useItems;
        savedata.GetUseItems(out useItems);
        return useItems;
    }
    public static bool UseItemSave(int useId, int itemId)
    {
        savedata.SetUseItem(useId, itemId);
        return Save();
    }
    public static int UseItemLoad(int useId)
    {
        Load();
        return savedata.GetUseItem(useId);
    }
    
    public static bool ItemsSave(int[] i)
    {
        savedata.SetItems(i);
        return Save();
    }
    public static int[] ItemsLoad()
    {
        Load();
        int[] items;
        savedata.GetItems(out items);
        return items;
    }
    public static bool ItemSave(int id, int num)
    {
        savedata.SetItemNum(id, num);
        return Save();
    }
    public static int ItemLoad(int id)
    {
        Load();
        return savedata.GetItemNum(id);
    }
    
    public static bool VolumeSave(float mVolume, float bgVolume, float seVolume)
    {
        savedata.SetVolumeAll(mVolume, bgVolume, seVolume);
        return Save();
    }
    public static float MasterVolumeLoad()
    {
        Load();
        return savedata.GetMasterVolume();
    }
    public static float BGMVolumeLoad()
    {
        Load();
        return savedata.GetBGMVolume();
    }
    public static float SEVolumeLoad()
    {
        Load();
        return savedata.GetSEVolume();
    }
    
    public static bool ClearStageSave(int stageID, bool flag)
    {
        savedata.SetClearStage(stageID, flag);
        return Save();
    }
    public static bool ClaerStageSave(bool[] flag)
    {
        savedata.SetClearStage(flag);
        return Save();
    }
    public static bool ClearStageLoad(int stageID)
    {
        Load();
        return savedata.GetClearStageFlag(stageID);
    }
    public static bool[] ClearStageLoad()
    {
        Load();
        bool[] res;
        savedata.GetClearStageFlag(out res);
        return res;
    }
    
    public static bool OpenStageSave(int stageID, bool flag)
    {
        savedata.SetOpenStage(stageID, flag);
        return Save();
    }
    public static bool OpenStageSave(bool[] flag)
    {
        savedata.SetOpenStage(flag);
        return Save();
    }
    public static bool OpenStageLoad(int stageID)
    {
        Load();
        return savedata.GetOpenStageFlag(stageID);
    }
    public static bool[] OpenStageLoad()
    {
        Load();
        bool[] res;
        savedata.GetOpenStageFlag(out res);
        return res;
    }
}
