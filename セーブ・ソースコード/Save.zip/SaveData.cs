using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class SaveData
{
    private float mVolume, bgVolume, seVolume;
    private int money;
    private bool[] clearStage;
    private bool[] openStage;
    
    private int[] cards;
    
    private int selectDeck;
    private int[,] deck = new int[3, 6];
    
    private int[] items;
    private int[] useItems = new int[2];
    
    public SaveData()
    {
        ResetData();
    }
    
    public byte[] ConvertToByte()
    {
        int intSize;
        byte[] bitSize;
        byte[] bitHeader = new byte[]{
            0x48, 0x43,
            0x33, 0x39,
            0x00, 0x00, 0x00, 0x00,     // ファイルサイズ
            0x00, 0x00, 0x00, 0x00      // データ格納位置
        };
        byte[] bitPointsHeader = new byte[]{
            0x00, 0x00, 0x00, 0x00,     // サイズ
            0x00, 0x00, 0x00, 0x00,     // 音量
            0x00, 0x00, 0x00, 0x00,     // お金
            0x00, 0x00, 0x00, 0x00,     // ステージクリア情報
            0x00, 0x00, 0x00, 0x00,     // ステージ開放情報
            0x00, 0x00, 0x00, 0x00,     // カード所持数
            0x00, 0x00, 0x00, 0x00,     // デッキ情報
            0x00, 0x00, 0x00, 0x00,     // アイテム所持数
            0x00, 0x00, 0x00, 0x00      // 使用アイテム
        };
        intSize = bitPointsHeader.Length;
        bitSize = BitConverter.GetBytes(intSize);
        for(int i=0; i<bitSize.Length; i++)
        {
            bitPointsHeader[i] = bitSize[i];
        }
        intSize += bitHeader.Length;
        bitSize = BitConverter.GetBytes(intSize);
        for(int i=0; i<bitSize.Length; i++)
        {
            bitPointsHeader[4+i] = bitSize[i];
            bitHeader[8+i] = bitSize[i];
        }
        
        byte[] bitMVol = BitConverter.GetBytes(mVolume);
        byte[] bitBVol = BitConverter.GetBytes(bgVolume);
        byte[] bitSVol = BitConverter.GetBytes(seVolume);
        byte[] bitVolume = new byte[bitMVol.Length+bitBVol.Length+bitSVol.Length];
        for(int i=0; i<bitVolume.Length; i++)
        {
            if(i<bitMVol.Length){bitVolume[i] = bitMVol[i];}
            else if(i<bitMVol.Length+bitBVol.Length){bitVolume[i] = bitBVol[i-bitMVol.Length];}
            else {bitVolume[i] = bitSVol[i-(bitMVol.Length+bitBVol.Length)];}
        }
        intSize += bitVolume.Length;
        bitSize = BitConverter.GetBytes(intSize);
        for(int i=0; i<bitSize.Length; i++)
        {
            bitPointsHeader[8+i] = bitSize[i];
        }
        
        byte[] bitMoney = BitConverter.GetBytes(money);
        intSize += bitMoney.Length;
        bitSize = BitConverter.GetBytes(intSize);
        for(int i=0; i<bitSize.Length; i++)
        {
            bitPointsHeader[12+i] = bitSize[i];
        }
        
        byte[] bitCStage = new byte[clearStage.Length+4];
        byte[] bitOStage = new byte[openStage.Length+4];
        byte[] bitWork = BitConverter.GetBytes(clearStage.Length);
        for(int i=0; i<clearStage.Length; i++)
        {
            if(i < 4)
            {
                bitCStage[i] = bitWork[i];
                bitOStage[i] = bitWork[i];
            }
            else
            {
                if(clearStage[i-4])
                {
                    bitCStage[i] = 0x01;
                }
                else
                {
                    bitCStage[i] = 0x00;
                }
                
                if(openStage[i-4])
                {
                    bitOStage[i] = 0x01;
                }
                else
                {
                    bitOStage[i] = 0x00;
                }
            }
        }
        intSize += bitCStage.Length;
        bitSize = BitConverter.GetBytes(intSize);
        for(int i=0; i<bitSize.Length; i++)
        {
            bitPointsHeader[16+i] = bitSize[i];
        }
        intSize += bitOStage.Length;
        bitSize = BitConverter.GetBytes(intSize);
        for(int i=0; i<bitSize.Length; i++)
        {
            bitPointsHeader[20+i] = bitSize[i];
        }
        
        byte[] bitCards = new byte[4*(cards.Length+1)];
        bitWork = BitConverter.GetBytes(cards.Length);
        for(int i=0; i<bitCards.Length; i++)
        {
            if(i >= 4 && i%4 == 0)
            {
                bitWork = BitConverter.GetBytes(cards[i/4-1]);
            }
            bitCards[i] = bitWork[i%4];
        }
        intSize += bitCards.Length;
        bitSize = BitConverter.GetBytes(intSize);
        for(int i=0; i<bitSize.Length; i++)
        {
            bitPointsHeader[24+i] = bitSize[i];
        }
        
        byte[] bitDeck = new byte[4*(1+deck.Length)];
        bitWork = BitConverter.GetBytes(selectDeck);
        for(int i=0; i<bitDeck.Length; i++)
        {
            if(i >= 4 && i%4 == 0)
            {
                int n = i/4 - 1;
                bitWork = BitConverter.GetBytes(deck[n/6,n%6]);
            }
            bitDeck[i] = bitWork[i%4];
        }
        intSize += bitDeck.Length;
        bitSize = BitConverter.GetBytes(intSize);
        for(int i=0; i<bitSize.Length; i++)
        {
            bitPointsHeader[28+i] = bitSize[i];
        }
        
        byte[] bitItem = new byte[4*(items.Length+1)];
        bitWork = BitConverter.GetBytes(items.Length);
        for(int i=0; i<bitItem.Length; i++)
        {
            if(i >= 4 && i%4 == 0)
            {
                bitWork = BitConverter.GetBytes(items[i/4-1]);
            }
            bitItem[i] = bitWork[i%4];
        }
        intSize += bitItem.Length;
        bitSize = BitConverter.GetBytes(intSize);
        for(int i=0; i<bitSize.Length; i++)
        {
            bitPointsHeader[32+i] = bitSize[i];
        }
        
        byte[] bitUseItem = new byte[4*(useItems.Length)];
        for(int i=0; i<bitUseItem.Length; i++)
        {
            if(i%4 == 0)
            {
                bitWork = BitConverter.GetBytes(useItems[i/4]);
            }
            bitUseItem[i] = bitWork[i%4];
        }
        intSize += bitUseItem.Length;
        bitSize = BitConverter.GetBytes(intSize);
        for(int i=0; i<bitSize.Length; i++)
        {
            bitHeader[4+i] = bitSize[i];
        }
        
        byte[] data = new byte[intSize];
        intSize = 0;
        for(int i=0; i<bitHeader.Length; i++)
        {
            data[intSize++] = bitHeader[i];
        }
        for(int i=0; i<bitPointsHeader.Length; i++)
        {
            data[intSize++] = bitPointsHeader[i];
        }
        for(int i=0; i<bitVolume.Length; i++)
        {
            data[intSize++] = bitVolume[i];
        }
        for(int i=0; i<bitMoney.Length; i++)
        {
            data[intSize++] = bitMoney[i];
        }
        for(int i=0; i<bitCStage.Length; i++)
        {
            data[intSize++] = bitCStage[i];
        }
        for(int i=0; i<bitOStage.Length; i++)
        {
            data[intSize++] = bitOStage[i];
        }
        for(int i=0; i<bitCards.Length; i++)
        {
            data[intSize++] = bitCards[i];
        }
        for(int i=0; i<bitDeck.Length; i++)
        {
            data[intSize++] = bitDeck[i];
        }
        for(int i=0; i<bitItem.Length; i++)
        {
            data[intSize++] = bitItem[i];
        }
        for(int i=0; i<bitUseItem.Length; i++)
        {
            data[intSize++] = bitUseItem[i];
        }

        return data;
    }
    public void ConvertFromByte(byte[] data)
    {
        if(data.Length < 48)
        {
            ResetData();
            return;
        }
        int p = BitConverter.ToInt32(data, 16);
        mVolume = BitConverter.ToSingle(data, p);
        bgVolume = BitConverter.ToSingle(data, p + 4);
        seVolume = BitConverter.ToSingle(data, p + 8);

        p = BitConverter.ToInt32(data, 20);
        money = BitConverter.ToInt32(data, p);

        p = BitConverter.ToInt32(data, 24);
        int intSize = BitConverter.ToInt32(data, p);
        if(intSize < StageData.GetStageNumAll())
        {
            clearStage = new bool[StageData.GetStageNumAll()];
        }
        else
        {
            clearStage = new bool[intSize];
        }
        for(int i=0; i<clearStage.Length; i++)
        {
            if(data[p+4+i] == 0x01 && i<intSize)
            {
                clearStage[i] = true;
            }
            else
            {
                clearStage[i] = false;
            }
        }

        p = BitConverter.ToInt32(data, 28);
        intSize = BitConverter.ToInt32(data, p);
        if(intSize < StageData.GetStageNumAll())
        {
            openStage = new bool[StageData.GetStageNumAll()];
        }
        else
        {
            openStage = new bool[intSize];
        }
        for(int i=0; i<openStage.Length; i++)
        {
            if (data[p + 4 + i] == 0x01 && i<intSize)
            {
                openStage[i] = true;
            }
            else
            {
                openStage[i] = false;
            }
        }

        p = BitConverter.ToInt32(data, 32);
        intSize = BitConverter.ToInt32(data, p);
        if(intSize < CardData.GetAllCardDataNum())
        {
            cards = new int[CardData.GetAllCardDataNum()];
        }
        else
        {
            cards = new int[intSize];
        }
        for(int i=0; i<cards.Length; i++)
        {
            if(i < intSize)
            {
                cards[i] = BitConverter.ToInt32(data, p + 4 + 4 * i);
            }
            else
            {
                cards[i] = -1;
            }
        }

        p = BitConverter.ToInt32(data, 36);
        selectDeck = BitConverter.ToInt32(data, p);
        for(int i=0; i<deck.GetLength(0); i++)
        {
            for(int j=0; j<deck.GetLength(1); j++)
            {
                deck[i, j] = BitConverter.ToInt32(data, p + 4 + 4 * (6 * i + j));
            }
        }

        p = BitConverter.ToInt32(data, 40);
        intSize = BitConverter.ToInt32(data, p);
        if(intSize < ItemData.GetItemDataNum())
        {
            items = new int[ItemData.GetItemDataNum()];
        }
        else
        {
            items = new int[intSize];
        }
        for(int i=0; i<items.Length; i++)
        {
            if(i < intSize)
            {
                items[i] = BitConverter.ToInt32(data, p + 4 + 4 * i);
            }
            else
            {
                items[i] = 0;
            }
        }

        p = BitConverter.ToInt32(data, 44);
        for(int i=0; i<useItems.Length; i++)
        {
            useItems[i] = BitConverter.ToInt32(data, p + 4 * i);
        }
    }
    
    public void ResetData()
    {
        mVolume = bgVolume = seVolume = 1.0f;
        money = 0;
        clearStage = new bool[StageData.GetStageNumAll()];
        for(int i=0; i<clearStage.Length; i++)
        {
            clearStage[i] = false;
        }
        openStage = new bool[StageData.GetStageNumAll()];
        for(int i=0; i<openStage.Length; i++)
        {
            openStage[i] = false;
        }
        
        deck = new int[,]{
            {0, 1, 2, 3, 4, 5},
            {-1, -1, -1, -1, -1, -1},
            {-1, -1, -1, -1, -1, -1}
        };
        selectDeck = 0;
        
        cards = new int[CardData.GetAllCardDataNum()];
        for(int i=0; i<cards.Length; i++)
        {
            cards[i] = -1;
        }
        
        CardNumAdjust();
        
        items = new int[ItemData.GetItemDataNum()];
        useItems = new int[]{0, 0};
    }
    
    private void CardNumAdjust()
    {
        for(int i=0; i<deck.GetLength(0); i++)
        {
            for(int j=0; j<deck.GetLength(1); j++)
            {
                if(deck[i, j] != -1 && cards[deck[i, j]] == -1)
                {
                    cards[deck[i, j]] = 0;
                }
            }
        }
    }
    
    /* ---- お金 ---- */
    public void SetMoney(int g){money = g;}
    public int GetMoney(){return money;}
    /* ---- デッキ ---- */
    public void SetDeck(int n, int[] d)
    {
        int w = selectDeck;
        if(n == selectDeck)
        {
            w = -1;
        }
        selectDeck = n;
        for(int i=0; i<deck.GetLength(1) && i<d.Length; i++)
        {
            deck[n, i] = d[i];
            if(deck[n, i] == -1)
            {
                selectDeck = w;
            }
        }
        
        CardNumAdjust();
    }
    public void GetDeck(out int[] d, int n)
    {
        int w = selectDeck;
        if(n == selectDeck)
        {
           w = -1;
        }
        d = new int[deck.GetLength(1)];
        for(int i=0; i<deck.GetLength(1); i++)
        {
            d[i] = deck[n, i];
            if(deck[n, i] == -1)
            {
                selectDeck = w;
            }
        }
    }
    public void GetDeck(out int[] d)
    {
        d = new int[deck.GetLength(1)];
        for(int i=0; i<deck.GetLength(1); i++)
        {
            if(selectDeck != -1)
            {
                d[i] = deck[selectDeck, i];
            }
            else
            {
                d[i] = -1;
            }
        }
    }
    public void SetSelectDeck(int n){selectDeck = n;}
    public int GetSelectDeck(){return selectDeck;}
    /* ---- カード ---- */
    public void SetCardNum(int id, int num)
    {
        if(id < 0 || id >= cards.Length)
        {
            return;
        }
        
        if(cards[id] == -1 && num == 0)
        {
            cards[id] = -1;
        }
        else
        {
            cards[id] = num;
        }
        CardNumAdjust();
    }
    public int GetCardNum(int id)
    {
        if(id < 0 || id >= cards.Length || cards[id] == -1)
        {
            return 0;
        }
        return cards[id];
    }
    public bool GetCardFlag(int id){return cards[id] != -1;}
    /* ---- アイテム ---- */
    public void SetUseItems(int[] i)
    {
        useItems[0] = i[0];
        useItems[1] = i[1];
    }
    public void GetUseItems(out int[] i)
    {
        i = new int[2];
        for(int j=0; j<useItems.Length; j++)
        {
            i[j] = useItems[j];
        }
    }
    public void SetUseItem(int n, int item){useItems[n] = item;}
    public int GetUseItem(int n){return useItems[n];}
    public void SetItems(int[] i)
    {
        for(int j=0; j<items.Length; j++)
        {
            items[j] = i[j];
        }
    }
    public void GetItems(out int[] i)
    {
        i = new int[items.Length];
        for(int j=0; j<items.Length; j++)
        {
            i[j] = items[j];
        }
    }
    public void SetItemNum(int id, int num){items[id] = num;}
    public int GetItemNum(int id){return items[id];}
    /* ---- 音量 ---- */
    public void SetVolumeAll(float m, float bg, float se)
    {
        mVolume = m;
        bgVolume = bg;
        seVolume = se;
    }
    public float GetMasterVolume(){return mVolume;}
    public float GetBGMVolume(){return bgVolume;}
    public float GetSEVolume(){return seVolume;}
    /* ---- ステージ ---- */
    public void SetClearStage(int n, bool flag){clearStage[n] = flag;}
    public void SetClearStage(bool[] flag)
    {
        for(int i=0; i<clearStage.Length && i<flag.Length; i++)
        {
            clearStage[i] = flag[i];
        }
    }
    public bool GetClearStageFlag(int n){return clearStage[n];}
    public void GetClearStageFlag(out bool[] flag)
    {
        flag = new bool[clearStage.Length];
        for(int i=0; i<clearStage.Length; i++)
        {
            flag[i] = clearStage[i];
        }
    }
    public void SetOpenStage(int n, bool flag){openStage[n] = flag;}
    public void SetOpenStage(bool[] flag)
    {
        for(int i=0; i<openStage.Length && i<flag.Length; i++)
        {
            openStage[i] = flag[i];
        }
    }
    public bool GetOpenStageFlag(int n){return openStage[n];}
    public void GetOpenStageFlag(out bool[] flag)
    {
        flag = new bool[openStage.Length];
        for(int i=0; i<openStage.Length; i++)
        {
            flag[i] = openStage[i];
        }
    }
}
