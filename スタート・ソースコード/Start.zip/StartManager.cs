using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StartManager : MonoBehaviour
{
    SoundManager sound;
    // Start is called before the first frame update
    void Start()
    {
        SaveManager.SetStarting();
        sound = FindObjectOfType<SoundManager>();
        if(!SaveManager.SaveFileExists())
        {
            SaveManager.Save();
            sound.Volume = SaveManager.MasterVolumeLoad();
            sound.BgmVolume = SaveManager.BGMVolumeLoad();
            sound.SeVolume = SaveManager.SEVolumeLoad();
            MovieManager.nextScene = "Titlemain";
            MovieManager.movieID = 0;
            SceneManager.LoadScene("Movie");
        }
        else
        {
            sound.Volume = SaveManager.MasterVolumeLoad();
            sound.BgmVolume = SaveManager.BGMVolumeLoad();
            sound.SeVolume = SaveManager.SEVolumeLoad();
            SceneManager.LoadScene("Titlemain");
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
