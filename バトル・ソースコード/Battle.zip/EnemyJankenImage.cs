using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnemyJankenImage : MonoBehaviour
{
    private Image image;
    public Sprite[] sprite;
    
    // 透明度
    private float alpha;
    // 透明化するときの変化量
    public float deltaA;
    
    // Start is called before the first frame update
    void Start()
    {
        image = this.GetComponent<Image>();
        
        // はじめは透明
        alpha = 0.0f;
        image.color = new Color(1.0f, 1.0f, 1.0f, alpha);
    }

    // Update is called once per frame
    void Update()
    {
        image.color = new Color(1.0f, 1.0f, 1.0f, alpha);
        
        // 不透明なら徐々に透明化
        if(alpha > 0.0f)
        {
            alpha -= deltaA;
            if(alpha < 0.0f)
            {
                alpha = 0.0f;
            }
        }
    }
    
    // じゃんけんの手を表示する
    public void SetJanken(int janken)
    {
        image.sprite = sprite[janken];
        alpha = 1.0f;
    }
}
