using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Enemy : MonoBehaviour
{
    private int maxHp;
    private int hp;
    private int pow;
    private int janken;
    private int pattern;
    private string enemyName;
    
    public EnemyImage enemyImage;
    public EnemyJankenImage enemyJankenImage;
    public HP enemyHP;
    public Text enemyNameText;
    
    public void Init(EnemyData data)
    {
        maxHp = data.hp;
        hp = maxHp;
        pow = data.power;
        janken = Random.Range(0, 3);
        pattern = data.patterns[Random.Range(0, data.patterns.Length)];
        enemyName = data.name;
        
        enemyImage.SetImage(data.image);
        enemyHP.ShowHP(maxHp, hp);
        enemyNameText.text = enemyName;
    }
    
    public void Init(int h, int p, string n)
    {
        maxHp = h;
        hp = maxHp;
        pow = p;
        enemyName = n;
        
        janken = Random.Range(0, 3);
        pattern = Random.Range(0, 4);
        
        enemyImage.SetImage(enemyName);
        enemyHP.ShowHP(maxHp, hp);
    }
    
    public bool IsOK()
    {
        return enemyImage.IsOK();
    }
    
    public int GetJanken()
    {
        switch(pattern)
        {
            case 0:
                // 前より弱い手を出す
                janken++;
                break;
            case 1:
                // 前より強い手を出す
                janken--;
                break;
            case 2:
                // 前と同じか弱い手を出す
                janken += Random.Range(0, 2);
                break;
            case 3:
                // 前と同じか強い手を出す
                janken -= Random.Range(0, 2);
                break;
            case 4:
                // 前回とは違う手を出す
                if(Random.Range(0, 2) == 0)
                {
                    janken++;
                }
                else
                {
                    janken--;
                }
                break;
            default:
                // その他（ランダムな手を出す）
                janken = Random.Range(0, 3);
                // 次回以降パターンを0とする
                pattern = 0;
                break;
        }
        
        // jankenの値を0~2に調整する
        janken = (janken + 3) % 3;
        
        enemyJankenImage.SetJanken(janken);
        
        return janken;
    }
    
    public int GetPow()
    {
        return pow;
    }
    
    public int GetHP()
    {
        return hp;
    }
    
    public Sprite GetImage()
    {
        return enemyImage.image.sprite;
    }
    
    public void Damage(int damage)
    {
        hp -= damage;
        
        // hpが0を下回らないようにする
        if(hp < 0)
        {
            hp = 0;
        }
        
        enemyHP.ShowHP(maxHp, hp);
        
        if(hp == 0)
        {
            enemyImage.SetFadeOut();
        }
    }
    
    public int GetJankenNow()
    {
        return janken;
    }
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
