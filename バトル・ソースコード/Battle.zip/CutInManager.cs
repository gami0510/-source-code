using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CutInManager : MonoBehaviour
{
    private float back_r, back_g, back_b, back_a;
    private Image backImage;
    private int fade = 0;
    public GameObject cutInBack;
    public Transform cutInPlayer;
    public Transform cutInEnemy;
    private Vector3 pImagePos, eImagePos;
    private float pDeltaX, eDeltaX;
    private float pSpeed, eSpeed;
    private int cnt = 0;
    
    void Awake()
    {
        backImage = cutInBack.GetComponent<Image>();
        back_r = backImage.color.r;
        back_g = backImage.color.g;
        back_b = backImage.color.b;
        back_a = 0.0f;
        cutInBack.SetActive(false);
        
        pImagePos = cutInPlayer.position;
        pDeltaX = pImagePos.x + 120.0f;
        cutInPlayer.gameObject.SetActive(false);
        eImagePos = cutInEnemy.position;
        eDeltaX = 800.0f - eImagePos.x +120.0f;
        cutInEnemy.gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        switch(fade)
        {
            case 0:
                // 動作なし
                break;
            case 1:
                // 背景出現準備
                cutInBack.SetActive(true);
                backImage.color = new Color(back_r, back_g, back_b, back_a);
                fade = 2;
                break;
            case 2:
                // 背景フェードイン
                back_a += 0.1f;
                backImage.color = new Color(back_r, back_g, back_b, back_a);
                if(back_a >= 1.0f)
                {
                    fade = 5;
                    cnt = 0;
                }
                break;
            case 3:
                // プレイヤー出現準備
                if(++cnt == 20)
                {
                    cutInPlayer.position = pImagePos + Vector3.left * pDeltaX;
                    pSpeed = pDeltaX / 20.0f;
                    cutInPlayer.gameObject.SetActive(true);
                    fade = 4;
                    cnt = 0;
                }
                break;
            case 4:
                // プレイヤー出現
                cutInPlayer.position += Vector3.right * pSpeed;
                cnt++;
                if(cutInPlayer.position.x >= pImagePos.x || (Input.GetMouseButton(0) && cnt > 10))
                {
                    cutInPlayer.position = pImagePos;
                    fade = 7;
                    cnt = 0;
                }
                break;
            case 5:
                // エネミー出現準備
                if(++cnt == 20)
                {
                    cutInEnemy.position = eImagePos + Vector3.right * eDeltaX;
                    eSpeed = eDeltaX / 20.0f;
                    cutInEnemy.gameObject.SetActive(true);
                    fade = 6;
                    cnt = 0;
                }
                break;
            case 6:
                // エネミー出現
                cutInEnemy.position += Vector3.left * eSpeed;
                cnt++;
                if(cutInEnemy.position.x <= eImagePos.x || (Input.GetMouseButton(0) && cnt > 10))
                {
                    cutInEnemy.position = eImagePos;
                    fade = 3;
                    cnt = 0;
                }
                break;
            case 7:
                // 待機時間
                if(++cnt >= 120 || (Input.GetMouseButton(0) && cnt > 10))
                {
                    // プレイヤー&エネミー退場準備
                    pSpeed = pDeltaX / 10.0f;
                    eSpeed = eDeltaX / 10.0f;
                    fade = 8;
                }
                break;
            case 8:
                // プレイヤー&エネミー退場
                cutInPlayer.position += Vector3.left * pSpeed;
                cutInEnemy.position += Vector3.right * eSpeed;
                if(cutInPlayer.position.x <= pImagePos.x - pDeltaX && cutInEnemy.position.x >= eImagePos.x + eDeltaX)
                {
                    cutInPlayer.gameObject.SetActive(false);
                    cutInEnemy.gameObject.SetActive(false);
                    fade = 9;
                }
                break;
            case 9:
                // 背景フェードアウト
                back_a -= 0.1f;
                backImage.color = new Color(back_r, back_g, back_b, back_a);
                if(back_a <= 0.0f)
                {
                    cutInBack.SetActive(false);
                    fade = 0;
                }
                break;
        }
    }
    
    public void StartCutIn()
    {
        if(fade == 0)
        {
            fade = 1;
        }
    }
    
    public bool CutInFlag()
    {
        return fade == 0;
    }
}
