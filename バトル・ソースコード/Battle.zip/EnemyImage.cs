using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnemyImage : MonoBehaviour
{
    public enum EnemyImageState
    {
        SET_OK,
        FADE_OUT,
        FADE_IN
    }
    
    private EnemyImageState state;
    
    public Image image;
    public Sprite[] sprite;
    
    private float r,g,b,a;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        image.color = new Color(1, 1, 1, a);
        switch(state)
        {
        case EnemyImageState.SET_OK:
            break;
        case EnemyImageState.FADE_OUT:
            a -= 0.1f;
            if(a < 0.0f)
            {
                a = 0.0f;
                state = EnemyImageState.SET_OK;
            }
            break;
        case EnemyImageState.FADE_IN:
            a += 0.1f;
            if(a > 1.0f)
            {
                a = 1.0f;
                state = EnemyImageState.SET_OK;
            }
            break;
        }
    }
    
    public bool IsOK()
    {
        return state == EnemyImageState.SET_OK;
    }
    
    public void SetFadeOut()
    {
        state = EnemyImageState.FADE_OUT;
    }
    
    public void SetImage(Sprite s)
    {
        image.sprite = s;
        a = 0.0f;
        state = EnemyImageState.FADE_IN;
    }
    
    public void SetImage(string n)
    {
        Sprite s = Resources.Load("EnemyImage/" + n, typeof(Sprite)) as Sprite;
        image.sprite = s;
        a = 0.0f;
        state = EnemyImageState.FADE_IN;
    }
}
