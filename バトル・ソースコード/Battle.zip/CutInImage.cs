using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CutInImage : MonoBehaviour
{
    public Image cardImage, jankenImage;
    public Enemy enemy;
    public bool isEnemy;
    
    void OnEnable()
    {
        if(isEnemy)
        {
            cardImage.sprite = enemy.GetImage();
            jankenImage.sprite = Resources.Load("JankenImage/" + enemy.GetJankenNow(), typeof(Sprite)) as Sprite;
        }
        else
        {
            cardImage.sprite = BattleManager.instance.GetSelectCardImage();
            jankenImage.sprite = Resources.Load("JankenImage/" + BattleManager.instance.GetPlayerJanken(), typeof(Sprite)) as Sprite;
        }
    }
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
