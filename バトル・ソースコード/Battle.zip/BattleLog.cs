using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BattleLog : MonoBehaviour
{
    [SerializeField] private Text logText;

    // ログの表示可能な行数
    private int lMaxnum = 8;
    // ログの行数
    private int lnum = 0;
    // ログ
    private string[] logs;

    // Start is called before the first frame update
    void Awake()
    {
        logText.text = "";
        logs = new string[lMaxnum];
        for(int i=0; i<lMaxnum; i++)
        {
            logs[i] = "";
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    // ログの追加
    public void addLog(string log)
    {
        if(lnum < lMaxnum)
        {
            logs[lnum] = log;
            lnum++;
        }
        else
        {
            for(int i=1; i<lMaxnum; i++)
            {
                logs[i-1] = logs[i];
            }
            logs[lMaxnum-1] = log;
        }
        
        logText.text = "";
        for(int i=0; i<lnum; i++)
        {
            logText.text += logs[i] + "\n";
        }
    }
}
