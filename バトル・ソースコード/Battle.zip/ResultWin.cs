using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ResultWin : MonoBehaviour
{
    public GameObject cardPrefab;
    
    public Transform houshu;
    public Text noCardText;
    public Text houshuGold;
    
    private const float DropCard1 = 25.0f;  // ���J�[�h�h���b�v��
    private const float DropCard2 = 30.0f;  // ��J�[�h�h���b�v��
    private const float DropCard3 = 35.0f;  // ���J�[�h�h���b�v��
    
    public void SetHoushu(StageData data)
    {
        houshuGold.text = "+" + data.gold + "G";
        
        int money = SaveManager.MoneyLoad() + data.gold;
        SaveManager.MoneySave(money);
        
        float randNum = Random.Range(0, 100*10) / 10.0f;
        int dropRarity = -1;
        if(randNum < DropCard1)
        {
            dropRarity = 2;
        }
        else if(randNum < DropCard1 + DropCard2)
        {
            dropRarity = 1;
        }
        else if(randNum < DropCard1 + DropCard2 + DropCard3)
        {
            dropRarity = 0;
        }
        
        int[] dCardsID = new int[5];
        int dNum = 0;
        for(int i=0; i<data.dropcardID.Length; i++)
        {
            CardData dCard = new CardData(data.dropcardID[i]);
            if(dCard.rarity == dropRarity)
            {
                dCardsID[dNum++] = dCard.id;
            }
        }
        
        if(dNum == 0)
        {
            noCardText.gameObject.SetActive(true);
        }
        else
        {
            noCardText.gameObject.SetActive(false);
            GameObject dCard = Instantiate(cardPrefab, houshu);
            dCard.transform.localPosition += Vector3.down * 20;
            int dCardID = dCardsID[Random.Range(0, dNum)];
            dCard.GetComponent<CardController>().SetCard(new CardData(dCardID));
            dCard.GetComponent<Button>().interactable = false;
            dCard.transform.localScale = Vector3.one * 0.7f;
            int cardNum = SaveManager.CardNumLoad(dCardID) + 1;
            SaveManager.CardNumSave(dCardID, cardNum);
        }
    }
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
