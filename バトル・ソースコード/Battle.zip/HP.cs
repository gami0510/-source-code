using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HP : MonoBehaviour
{
    public Transform hpBar;
    private int maxHp;
    private int hp;
    
    public void SetHP(int h)
    {
        maxHp = h;
        hp = h;
        ShowHP();
    }
    
    public void Damage(int d)
    {
        hp -= d;
        if(hp < 0)
        {
            hp = 0;
        }
        ShowHP();
    }
    
    public void ShowHP()
    {
        Vector3 scale = hpBar.localScale;
        scale.x = (float) hp / maxHp;
        hpBar.localScale = scale;
    }
    
    public void ShowHP(int mH, int h)
    {
        Vector3 scale = hpBar.localScale;
        scale.x = (float) h / mH;
        hpBar.localScale = scale;
    }
    
    public int GetHP()
    {
        return hp;
    }
    
    public void PlusHP(int h)
    {
        hp += h;
        if(hp > maxHp)
        {
            hp = maxHp;
        }
        ShowHP();
    }
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
