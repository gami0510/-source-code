using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class JankenDirector : MonoBehaviour
{
    [SerializeField] private BattleManager manager;
    
    private float delay = 0.5f;

    // ログ
    public BattleLog battleLog;

    // Start is called before the first frame update
    void Start()
    {
        StartGame();
    }

    void StartGame()
    {
        battleLog.addLog("バトル開始！！");
    }

    // JankenControllerから呼び出される関数。 勝敗を判定する関数を呼び出す
    public void ShowResult(int playerScore, int enemyScore)
    {
        if(!manager.IsAllOK())
        {
            return;
        }
        StartCoroutine(Judgement(delay, playerScore, enemyScore));
    }

    // 勝敗を判定する関数(コルーチン)
    private IEnumerator Judgement(float delay, int playerScore, int enemyScore)
    {
        while(!manager.DoingCutIn()){}
        manager.DoCutIn();
        yield return new WaitForSeconds(delay);
        while(!manager.DoingCutIn())
        {
            yield return new WaitForSeconds(delay);
        }
        // プレイヤーが勝つパターン
        // 1. プレイヤー: グー,   敵: チョキ
        // 2. プレイヤー: チョキ, 敵: パー
        // 3. プレイヤー: パー,   敵: グー
        if((playerScore == 0 && enemyScore == 1)
            || (playerScore == 1 && enemyScore == 2)
            || (playerScore == 2 && enemyScore == 0))
        {
            battleLog.addLog("あなた の こうげき！！！");
            manager.Battle(0);
            //battleLog.addLog("あいてに<color=#FFFF00>" + damage + "</color>のダメージ！");
        }
        else
        {
            battleLog.addLog("あいて の こうげき！！！");
            manager.Battle(1);
            //battleLog.addLog("じぶんに<color=#FF0000>" + damage + "</color>のダメージ！");
        }

        if (playerScore == enemyScore)
        {
            battleLog.addLog("あいこだよ");
            manager.Battle(2);
        }

        yield return new WaitForSeconds(delay);
        
        if(manager.IsAllOK())
        {
            manager.NextTurn();
        }

        yield break;
    }
}
