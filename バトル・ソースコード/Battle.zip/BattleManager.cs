using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BattleManager : MonoBehaviour
{
    // 敵
    public Enemy enemy;
    // バトル背景
    public Image battleFieldBack;
    
    // プレイヤーのHP
    public HP playerHP;
    
    // 手札の場所
    public Transform cardField;
    // カードプレハブ
    public GameObject cardPrefab;
    
    // アイテム
    public BattleItem[] item;
    
    // バトルリザルト
    public GameObject resultWin;
    public GameObject resultGameOver;
    
    // カットイン
    public CutInManager cutIn;
    // じゃんけんテキスト
    public Text jankenText;
    private Color jankenTextColor;
    
    // ステージデータ
    private StageData stageData;
    // 合計戦闘回数
    private int battleNumAll;
    // 何戦目か
    private int battleNum;
    
    // デッキ
    private CardData[] deck = new CardData[6];
    // デッキ用ポインタ
    private int pDeck = 0;
    // 手札
    private GameObject[] handCard = new GameObject[3];
    private CardData[] handData = new CardData[3];
    // 選択されたカードの手札の位置
    private int pHand;
    // カードが選択可能かどうか
    private bool selectFlag = true;
    
    // サポートアイテムによる攻撃力補正値
    private int deltaPow = 0;
    
    public static BattleManager instance;
    
    void Awake()
    {
        instance = this;
        
        int id = StageController.selectStageID;
        stageData = StageData.GetStageData(id);
        
        battleNumAll = stageData.field.Length;
        
        int[] itemsId = SaveManager.UseItemsLoad();
        for(int i=0; i<itemsId.Length && i<item.Length; i++)
        {
            item[i].SetItem(itemsId[i]);
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        BattleStart();
    }
    
    private void BattleStart()
    {
        resultWin.SetActive(false);
        resultGameOver.SetActive(false);
        battleNum = 0;
        playerHP.SetHP(100);
        SetEnemy();
        SetStage();
        SetDeck();
        DrawCardsAll();
        jankenTextColor = jankenText.color;
        jankenText.text = "じゃんけん";
    }
    
    private void SetStage()
    {
        Sprite s = Resources.Load("Back/back"+stageData.field[battleNum], typeof(Sprite)) as Sprite;
        battleFieldBack.sprite = s;
    }
    
    private void SetEnemy()
    {
        enemy.Init(stageData.enemies[battleNum]);
    }
    
    private void SetDeck()
    {
        int[] d = SaveManager.DeckLoad();
        for(int i=0; i<deck.Length; i++)
        {
            deck[i] = new CardData(d[i]);
        }
        
        ShuffleDeck();
    }
    
    private void ShuffleDeck()
    {
        for(int i=0; i<deck.Length; i++)
        {
            CardData cw = deck[i];
            int n = Random.Range(0, deck.Length);
            deck[i] = deck[n];
            deck[n] = cw;
        }
        pDeck = 0;
    }
    
    public void DrawCards()
    {
        if(pDeck >= deck.Length || pDeck < 0)
        {
            ShuffleDeck();
        }
        for(int i=0; i<handCard.Length; i++)
        {
            if(handCard[i] == null)
            {
                DrawCard(i);
            }
        }
    }
    
    public void DrawCardsAll()
    {
        if(pDeck >= deck.Length || pDeck < 0)
        {
            ShuffleDeck();
        }
        for(int i=0; i<handCard.Length; i++)
        {
            DrawCard(i);
        }
    }
    
    public void DrawCard(int handId)
    {
        if(pDeck >= deck.Length || pDeck < 0)
        {
            ShuffleDeck();
        }
        if(handCard[handId] == null)
        {
            handCard[handId] = Instantiate(cardPrefab, cardField);
            handCard[handId].transform.position += Vector3.left*280 + Vector3.right*130*handId;
        }
        handData[handId] = deck[pDeck++];
        handCard[handId].GetComponent<CardController>().SetCard(handData[handId], handId);
    }
    
    public void NextBattle()
    {
        if(++battleNum < battleNumAll)
        {
            SetEnemy();
            SetStage();
            DrawCard(pHand);
            selectFlag = true;
            
            jankenText.color = jankenTextColor;
            jankenText.text = "じゃんけん";
        }
        else
        {
            BattleEnd();
        }
    }
    
    public void NextTurn()
    {
        deltaPow = 0;
        for(int i=0; i<item.Length; i++)
        {
            item[i].ResetUseFlag();
        }
        if(playerHP.GetHP() == 0)
        {
            BattleEnd();
            return;
        }
        else if(enemy.GetHP() == 0)
        {
            NextBattle();
        }
        else
        {
            DrawCard(pHand);
            selectFlag = true;
            
            jankenText.color = jankenTextColor;
            jankenText.text = "じゃんけん";
        }
    }
    
    public void BattleEnd()
    {
        if(playerHP.GetHP() == 0)
        {
            resultGameOver.SetActive(true);
        }
        else
        {
            resultWin.SetActive(true);
            resultWin.GetComponent<ResultWin>().SetHoushu(stageData);
            SaveManager.ClearStageSave(stageData.id, true);
        }
    }
    
    public bool SelectCard(int handId)
    {
        if(selectFlag && enemy.IsOK())
        {
            jankenText.color = jankenTextColor;
            jankenText.text = "ぽん！";
            pHand = handId;
            selectFlag = false;
            return true;
        }
        
        return false;
    }
    
    public void DoCutIn()
    {
        cutIn.StartCutIn();
    }
    public bool DoingCutIn()
    {
        return cutIn.CutInFlag();
    }
    
    // じゃんけんの結果によって戦闘を行う
    public void Battle(int judge)
    {
        int damage = 1;
        int w;
        switch(judge)
        {
        case 0:
        // プレイヤーの勝ち
            w = GetAttack(handData[pHand]);
            damage = w;
            enemy.Damage(damage);
            jankenText.color = Color.red;
            jankenText.text = "あなた の こうげき！！！";
            break;
        case 1:
        // プレイヤーの負け
            w = GetDefence(handData[pHand]);
            damage = enemy.GetPow() - w;
            if(damage < 1)
            {
                damage = 1;
            }
            playerHP.Damage(damage);
            jankenText.color = Color.blue;
            jankenText.text = "あいて の こうげき！！！";
            break;
        case 2:
        // あいこ
            w = GetAttack(handData[pHand]);
            damage = w;
            if(damage >= enemy.GetHP())
            {
                damage = enemy.GetHP() - 1;
            }
            enemy.Damage(damage);
            
            w = GetDefence(handData[pHand]);
            damage = enemy.GetPow() - w;
            if(damage < 1)
            {
                damage = 1;
            }
            if(damage >= playerHP.GetHP())
            {
                damage = playerHP.GetHP() - 1;
            }
            playerHP.Damage(damage);
            jankenText.color = jankenTextColor;
            jankenText.text = "あいこだよ";
            break;
        }
    }
    
    // 攻撃力補正込計算
    private int GetAttack(CardData cData)
    {
        int pow = cData.pow;
        int delta = 0;
        int wField = stageData.field[battleNum];
        
        // フィールドによる補正
        if(cData.back == wField)
        {
            delta += 3;
        }
        if((cData.back == 0 && wField == 2) ||
            (cData.back == 1 && wField == 0) ||
            (cData.back == 2 && wField == 4) ||
            (cData.back == 3 && wField == 1) ||
            (cData.back == 4 && wField == 3))
        {
            delta -= 3;
        }
        
        // アイテムによる補正
        
        pow += delta;
        if(pow < 1)
        {
            pow = 1;
        }
        return pow;
    }
    
    // 防御力補正込計算
    private int GetDefence(CardData cData)
    {
        int def = cData.def;
        int delta = 0;
        int wField = stageData.field[battleNum];
        
        // フィールドによる補正
        if(cData.back == wField)
        {
            delta += 2;
        }
        if((cData.back == 0 && wField == 2) ||
            (cData.back == 1 && wField == 0) ||
            (cData.back == 2 && wField == 4) ||
            (cData.back == 3 && wField == 1) ||
            (cData.back == 4 && wField == 3))
        {
            delta -= 2;
        }
        
        def += delta;
        if(def < 0)
        {
            def = 0;
        }
        return def;
    }
    
    public int GetPlayerJanken()
    {
        return handData[pHand].type;
    }
    
    public Sprite GetSelectCardImage()
    {
        return handData[pHand].cardImage;
    }
    
    public void SupportItem(ItemData item)
    {
        switch(item.effect)
        {
            case 0:
                playerHP.PlusHP(item.capa);
                break;
            case 1:
                deltaPow += item.capa;
                break;
        }
    }
    
    public bool IsAllOK()
    {
        return enemy.IsOK();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
