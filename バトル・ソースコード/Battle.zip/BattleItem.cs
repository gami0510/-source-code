using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BattleItem : MonoBehaviour
{
    public Image itemImage;
    public GameObject frame;
    public Text itemNumText;
    
    private ItemData itemData;
    private int num;
    private bool useFlag;
    
    public void SetItem(int id)
    {
        itemData = ItemData.GetItemData(id);
        itemImage.sprite = itemData.image;
        num = SaveManager.ItemLoad(itemData.id);
        if(num == 0)
        {
            useFlag = false;
        }
        else
        {
            useFlag = true;
        }
    }
    
    public void ClickItem()
    {
        if(useFlag)
        {
            BattleManager.instance.SupportItem(itemData);
            useFlag = false;
            num--;
            SaveManager.ItemSave(itemData.id, num);
        }
    }
    
    public void ResetUseFlag()
    {
        if(num == 0)
        {
            useFlag = false;
        }
        else
        {
            useFlag = true;
        }
    }
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        frame.SetActive(!useFlag);
        itemNumText.text = "" + num;
    }
}
