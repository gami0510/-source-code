using UnityEngine;
using UnityEngine.SceneManagement;

public class OpenDeckKakunin : MonoBehaviour
{
    public void OnclickDeckKakuninButon()
    {
        SceneManager.LoadScene("DeckKakunin");
    }
}
