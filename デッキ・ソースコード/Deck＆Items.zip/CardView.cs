using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
 
public class CardView : MonoBehaviour
{
    [SerializeField] Text nameText, attackText, defenseText;
    [SerializeField] Image jankenSprite,back,cardSprite,rarity;

    public void Show(CardModel cardModel) // cardModel�̃f�[�^�擾�Ɣ��f
    {
        nameText.text = cardModel.CardName;
        attackText.text = cardModel.CardAttack.ToString();
        defenseText.text = cardModel.CardDefense.ToString();
        jankenSprite.sprite = cardModel.JankenSprite;
        back.sprite = cardModel.Back;
        cardSprite.sprite = cardModel.CardSprite;
        rarity.sprite = cardModel.Rarity;
    }
}
