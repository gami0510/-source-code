using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public static class SaveManager
{
    private static FileStream checkSaveFile()
    {
        string directory = Application.dataPath + @"/Save";
        string path = directory + "/savefile.sav";

        if(Directory.Exists(directory))
        {
            if(!File.Exists(path))
            {
                return File.Create(path);
            }
        }
        else
        {
            Directory.CreateDirectory(directory);
            return File.Create(path);
        }
        FileStream fileStream = File.Open(path, FileMode.Open);
        return fileStream;
    }

    public static bool Save()
    {
        string directory = Application.dataPath + @"/Save";
        string path = directory + "/savefile.sav";

        if(Directory.Exists(directory))
        {
            if(!File.Exists(path))
            {
                File.Create(path);
            }
        }
        else
        {
            Directory.CreateDirectory(directory);
            File.Create(path);
        }

        

        return true;
    }
    
    public static bool DeckSave(int deckNum, int[] deck)
    {
        Debug.Log(deckNum);
        return true;
    }
}
