using UnityEngine;
using UnityEngine.SceneManagement;

public class OpenDeckKakuninKesu : MonoBehaviour
{
    public void OnclickDeckKakuninKesuButon()
    {
        SceneManager.LoadScene("DeckKakuninKesu");
    }
}
